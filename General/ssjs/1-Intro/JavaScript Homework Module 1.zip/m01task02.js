﻿// Task02 - Write a code that returns sum of three inputted digits
// first, second and third - inpute values
// For example: if inpute values are 2, 3 and 5, you should return 10

function task02(first, second, third) {
    return first + second + third;
}