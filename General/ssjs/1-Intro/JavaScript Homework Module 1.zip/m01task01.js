﻿// Task01 - Write a code that returns any string value.
// For example, next code return a boolean value: 
// return false;

function task01() {
    return "string value";
}