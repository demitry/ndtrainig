﻿// Task03 - Write a code that returns concatenation of 2 inputted strings
// Use space (" ") as a string separator
// For example: 
// first is a string "Hello", second is a string "world!"
// You should return a string "Hello world!"

function task03(first, second) {
    return first + " " + second;
}