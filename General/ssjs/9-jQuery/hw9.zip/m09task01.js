﻿// Task01 
// Using jQuery immediately (without any effects) hide first paragraph 
// of target HTML document, all other elements should be visible

function m09task01() {
    // TODO: place your code here
    $('#test').hide();
}