﻿// Task02 
// Using jQuery immediately (without any effects) hide second and third paragraphs 
// of an HTML document, all other elements should be visible

function m09task02() {
    // TODO: place your code here
    $('.test').hide();
}