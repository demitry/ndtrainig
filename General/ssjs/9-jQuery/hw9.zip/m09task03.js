﻿// Task03 
// Using jQuery create click event handler for Button that 
// replaces content of a paragraph 4 with a number 42

function m09task03() {
    // TODO: place your code here
    $('#testButton').click(function(){
        $('#last').html('42');
    })
}