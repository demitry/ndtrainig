﻿// Task02 - create function with name task02
// Function should pass two parameters 
// and return number - sum of input parameters
// Note: strings should be casted to Number type

// TODO: Define your function here
