﻿// Task01 - create a function with name task01
// Function should return any string value

// TODO: Define your function here
function task01() {
    return "string value";
}